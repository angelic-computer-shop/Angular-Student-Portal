import { Injectable } from '@angular/core';
//import { from } from 'rxjs';
import {AngularFirestore} from '@angular/fire/firestore';
import { database } from 'firebase';

@Injectable({
  providedIn: 'root'
})
export class DatabaseService {

  constructor(public _fire: AngularFirestore) { }

  //add users function
  Adduser(data)
  {
   return this._fire.collection('Users').add(data).then(results=>{
     console.log("successfully added")
   }).catch(err=>{
     console.log('Err occured:', err
     )
   });


  }
  //get data from firestor
  GetUsers()
  {
     return this._fire.collection('Users');
  }
  //delete user function
  deletePersons(ref)
  {
    return this._fire.collection('Users').doc(ref).delete().then(results =>{
      console.log('sucessfully deleted')
    }).catch(err=>{
      console.log('error occured,',err);
    })
//update user
    UpdateUser()
    {
      //add this to our database
      return this._fire.collection('Users').doc(ref).update(database).then(results =>{
        console.log('sucessfully Updated')
    }).catch(err=>{
      console.log('error occured,',err);
    })
    
    }
  }
}
