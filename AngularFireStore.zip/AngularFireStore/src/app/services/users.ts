export interface Usersdata{
    name :string;
    surname:string;
    address:string;
    contact:number;
    course:string;
    
}
