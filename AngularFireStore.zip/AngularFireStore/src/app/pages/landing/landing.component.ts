import { Component, OnInit } from '@angular/core';

import { from } from 'rxjs';
import {NgForm} from '@angular/forms';
import { database } from 'firebase';
import { Action } from 'rxjs/internal/scheduler/Action';


@Component({
  selector: 'app-landing',
  templateUrl: './landing.component.html',
  styleUrls: ['./landing.component.scss']
})
export class LandingComponent {
  title = 'AngularFireTask';
  persons:any;

  constructor(public _data : DatabaseService) { }
  UpdateUser(UserData : NgForm)
  {
    //add this to our database
    this._data.Adduser(UserData.value);
  }


  deleteuser(ref){
    this._data.deletePersons(ref);
  } 
 

  ngOnInit() {
   
    
}
}