import { Component } from '@angular/core';
import { from } from 'rxjs';
import {NgForm} from '@angular/forms';
import { database } from 'firebase';
import {DatabaseService} from './services/database.service';
import { Action } from 'rxjs/internal/scheduler/Action';
import {Usersdata} from './services/users';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'AngularFireTask';
  persons:any;

  constructor(public _data : DatabaseService){}

  AddUsers(UserData : NgForm)
  {
    //add this to our database
    this._data.Adduser(UserData.value);
  }

 
ngOnInt()
{
//display data
this._data.GetUsers().valueChanges().subscribe( action =>{
  console.log(action);
  this.persons=action;

  action.map(element => {
    const UserInfo = element as Usersdata;
    console.log(UserInfo.name)
  })
  if(this.persons.name =="altharia"){
    console.log('is available')
  }

  
  

})
}
  
}
