import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { LandingComponent } from './pages/landing/landing.component';
import { AppComponent } from './app.component';


const routes: Routes = [
  {path: ' ' ,redirectTo : '/app',pathMatch:'full'},
{path: 'app', component : AppComponent},
{path: 'landing/:ref', component : LandingComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
